export interface Message {
    user: string;
    guild: string;
    content: string;
    creation: number;
}
